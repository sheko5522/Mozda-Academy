<?php
/**
 * General panel
 */
Kirki::add_panel( 'general', array(
	'title'          => esc_attr__( 'General', 'showbook' ),
	'description'    => esc_attr__( 'Customize general elements of the theme.', 'showbook' ),
	'priority'       => 130,
) );

/**
 * General section
 */
Kirki::add_section( 'general_settings', array(
	'title'          => esc_attr__( 'General Settings', 'showbook' ),
	'priority'       => 1,
	'panel'          => 'general'
) );

/**
 * Loading
 */
Kirki::add_field( 'showbook_options', array(
	'type'        => 'toggle',
	'settings'    => 'loading',
	'label'       => esc_attr__( 'Page Loading', 'showbook' ),
	'description' => esc_attr__( 'Enable page loading animation.', 'showbook' ),
	'section'     => 'general_settings',
	'default'     => '1',
) );
