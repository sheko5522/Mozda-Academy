<?php
/**
 * Site title section
 */
Kirki::add_section( 'site_title', array(
	'title'          => esc_attr__( 'Site Title', 'showbook' ),
	'priority'       => 5,
	'panel'          => 'header'
) );

/**
 * Site title
 */
Kirki::add_field( 'showbook_options', array(
	'type'        => 'typography',
	'settings'    => 'site_title_typography',
	'label'       => esc_attr__( 'Site Title', 'showbook' ),
	'section'     => 'site_title',
	'default'     => array(
		'font-family'    => 'Roboto',
		'variant'        => '700',
		'font-size'      => '30px',
		'letter-spacing' => '0',
		'color'          => '#000000',
		'text-transform' => 'uppercase'
	),
	'output'       => array(
		array(
			'element'  => '.site-title a',
			'suffix'   => '!important'
		),
	),
) );
