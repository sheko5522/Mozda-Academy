<?php
/**
 * Typography section
 */
Kirki::add_section( 'typography', array(
	'title'          => esc_attr__( 'Global Typography', 'showbook' ),
	'priority'       => 5,
	'panel'          => 'appearance'
) );

/**
 * Body text
 */
Kirki::add_field( 'showbook_options', array(
	'type'        => 'typography',
	'settings'    => 'body_text',
	'label'       => esc_attr__( 'Body Text', 'showbook' ),
	'section'     => 'typography',
	'default'     => array(
		'font-family'    => 'Roboto',
		'variant'        => 'regular',
		'font-size'      => '15px',
		'letter-spacing' => '0',
		'text-transform' => 'none'
	),
	'output'       => array(
		array(
			'element'  => 'body'
		),
	),
) );

/**
 * Heading text
 */
Kirki::add_field( 'showbook_options', array(
	'type'        => 'typography',
	'settings'    => 'heading_text',
	'label'       => esc_attr__( 'Heading Text', 'showbook' ),
	'section'     => 'typography',
	'default'     => array(
		'font-family'    => 'Roboto',
		'variant'        => '500',
		'letter-spacing' => '0',
		'text-transform' => 'none'
	),
	'output'       => array(
		array(
			'element'  => showbook_heading_selector()
		),
	),
) );
