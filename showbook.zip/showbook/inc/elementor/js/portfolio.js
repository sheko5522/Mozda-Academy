( function ( $ ) {

	var widgetPortfolio = function ( $scope, $ ) {

		// Set up variable
		var $wrapper = $( '.showbook-portfolio' ),
			gutter = 28,
			columns = 3,
			bigItemWidth;

		// no-gutter
		if ( $wrapper.hasClass( 'no-gutter' ) ) {
			gutter = 0;
		}

		// small gutter
		if ( $wrapper.hasClass( 'small-gutter' ) ) {
			gutter = 14;
		}

		// mosaic layout
		if ( $wrapper.hasClass( 'modern-style' ) ) {
			columns = 4;
		}

		// two-columns layout
		if ( $wrapper.hasClass( 'two-columns-style' ) ) {
			columns = 2;
		}

		// four-columns layout
		if ( $wrapper.hasClass( 'four-columns-style' ) ) {
			columns = 4;
		}

		// Re-set columns based on window width
		var windowWidth = $( 'body' ).width();

		if ( windowWidth <= 576 ) {
			columns = 1;
		} else if ( windowWidth <= 992 ) {
			columns = 2;
		}

		var itemWidth = ( $wrapper.width() - gutter * ( columns - 1 ) ) / columns;

		$( '.masonry-layout' ).css( {
			width: itemWidth,
			marginBottom: gutter
		} );

		if ( windowWidth >= 992 ) {
			bigItemWidth = ( itemWidth * 2 ) + gutter;

			$( '.big-post' ).css( {
				width: bigItemWidth
			} );
		}

		// Initialize isotope
		$wrapper.imagesLoaded( function () {
			$wrapper.isotope( {
				layoutMode: 'masonry',
				itemSelector: '.masonry-layout',
				percentPosition: true,
				masonry: {
					columnWidth: itemWidth,
					gutter: gutter,
				}
			} );
		} );

		// Filter links
		$( '#portfolio-filters' ).on( 'click', 'a', function ( event ) {
			event.preventDefault();

			var selector = $( this ).attr( 'data-filter' );
			$wrapper.isotope( {
				filter: selector
			} );

			$( this ).closest( 'ul' ).find( 'li' ).removeClass( 'active' );
			$( this ).closest( 'li' ).addClass( 'active' );

		} );

	};

	// Make sure we run this code under Elementor
	$( window ).on( 'elementor/frontend/init', function () {
		elementorFrontend.hooks.addAction( 'frontend/element_ready/showbook-portfolio.default', widgetPortfolio );
	} );

}( jQuery ) );
