<?php
/**
 * Portfolio Grid widgets
 */

namespace Elementor;

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Showbook_Portfolio_Widget extends Widget_Base {

	public function get_name() {
		return 'showbook-portfolio';
	}

	public function get_title() {
		return esc_html__( 'Portfolio', 'showbook' );
	}

	public function get_icon() {
		return 'eicon-posts-grid';
	}

	public function get_script_depends() {
		return [ 'showbook-portfolio', 'showbook-isotope' ];
	}

	public function get_categories() {
		return [ 'tj_extras_elements' ];
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'section_portfolio',
			[
				'label' => esc_html__( 'Portfolio', 'showbook' ),
			]
		);

		$this->add_control(
			'count',
			[
				'label' 		=> esc_html__( 'Posts Per Page', 'showbook' ),
				'description' 	=> esc_html__( 'You can enter "-1" to display all portfolio.', 'showbook' ),
				'type' 			=> Controls_Manager::TEXT,
				'default' 		=> '6',
				'label_block' 	=> true,
			]
		);

		$this->add_control(
			'order',
			[
				'label' 		=> esc_html__( 'Order', 'showbook' ),
				'type' 			=> Controls_Manager::SELECT,
				'default' 		=> '',
				'options' 		=> [
					'' 			=> esc_html__( 'Default', 'showbook' ),
					'DESC' 		=> esc_html__( 'DESC', 'showbook' ),
					'ASC' 		=> esc_html__( 'ASC', 'showbook' ),
				],
			]
		);

		$this->add_control(
			'orderby',
			[
				'label' 		=> esc_html__( 'Order By', 'showbook' ),
				'type' 			=> Controls_Manager::SELECT,
				'default' 		=> '',
				'options' 		=> [
					'' 				=> esc_html__( 'Default', 'showbook' ),
					'date' 			=> esc_html__( 'Date', 'showbook' ),
					'title' 		=> esc_html__( 'Title', 'showbook' ),
					'name' 			=> esc_html__( 'Name', 'showbook' ),
					'modified' 		=> esc_html__( 'Modified', 'showbook' ),
					'author' 		=> esc_html__( 'Author', 'showbook' ),
					'rand' 			=> esc_html__( 'Random', 'showbook' ),
					'ID' 			=> esc_html__( 'ID', 'showbook' ),
					'comment_count' => esc_html__( 'Comment Count', 'showbook' ),
					'menu_order' 	=> esc_html__( 'Menu Order', 'showbook' ),
				],
			]
		);

		$this->add_control(
			'include_categories',
			[
				'label' 		=> __( 'Include Categories', 'showbook' ),
				'description' 	=> __( 'Enter the categories slugs seperated by a "comma"', 'showbook' ),
				'type' 			=> Controls_Manager::TEXT,
				'label_block' 	=> true,
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_elements',
			[
				'label' => esc_html__( 'Elements', 'showbook' )
			]
		);

		$this->add_control(
			'image_size',
			[
				'label' 		=> esc_html__( 'Image Size', 'showbook' ),
				'type' 			=> Controls_Manager::SELECT,
				'default' 		=> 'showbook-featured',
				'options' 		=> $this->get_img_sizes(),
			]
		);

		$this->add_control(
			'filters',
			[
				'label' 		=> esc_html__( 'Display Filters', 'showbook' ),
				'type' 			=> Controls_Manager::SELECT,
				'default' 		=> 'true',
				'options' 		=> [
					'true' 		=> esc_html__( 'Show', 'showbook' ),
					'false' 	=> esc_html__( 'Hide', 'showbook' ),
				],
			]
		);

		$this->add_control(
			'title',
			[
				'label' 		=> esc_html__( 'Display Title', 'showbook' ),
				'type' 			=> Controls_Manager::SELECT,
				'default' 		=> 'true',
				'options' 		=> [
					'true' 		=> esc_html__( 'Show', 'showbook' ),
					'false' 	=> esc_html__( 'Hide', 'showbook' ),
				],
			]
		);

		$this->add_control(
			'cat',
			[
				'label' 		=> esc_html__( 'Display Categories', 'showbook' ),
				'type' 			=> Controls_Manager::SELECT,
				'default' 		=> 'true',
				'options' 		=> [
					'true' 		=> esc_html__( 'Show', 'showbook' ),
					'false' 	=> esc_html__( 'Hide', 'showbook' ),
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_filters_style',
			[
				'label' => esc_html__( 'Filters', 'showbook' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label' => esc_html__( 'Alignment', 'showbook' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'showbook' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'showbook' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'showbook' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'selectors' => [
					'{{WRAPPER}} #portfolio-filters' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'filters_margin',
			[
				'label' => esc_html__( 'Margin', 'showbook' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} #portfolio-filters' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator' => 'before',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_portfolio_style',
			[
				'label' => esc_html__( 'Portfolio', 'showbook' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'gutter',
			[
				'label' => __( 'Gutter', 'showbook' ),
				'type' => Controls_Manager::SWITCHER,
				'default' => 'yes'
			]
		);

		$this->add_control(
			'gutter_size',
			[
				'label' 		=> esc_html__( 'Gutter Size', 'showbook' ),
				'type' 			=> Controls_Manager::SELECT,
				'default' 		=> 'default',
				'options' 		=> [
					'default' 	=> esc_html__( 'Default', 'showbook' ),
					'small' 	=> esc_html__( 'Small', 'showbook' ),
				],
				'condition' => [
					'gutter' => 'yes',
				],
			]
		);

		$this->add_control(
			'style',
			[
				'label' 		=> esc_html__( 'Style', 'showbook' ),
				'type' 			=> Controls_Manager::SELECT,
				'default' 		=> 'default',
				'options' 		=> [
					'default' 	=> esc_html__( 'Default', 'showbook' ),
					'modern' 	=> esc_html__( 'Modern', 'showbook' ),
					'two_col' 	=> esc_html__( 'Two Columns', 'showbook' ),
					'four_col'  => esc_html__( 'Four Columns', 'showbook' ),
				],
			]
		);

		$this->end_controls_section();

	}

	public function get_img_sizes() {
		global $_wp_additional_image_sizes;

		$sizes = array();
		$get_intermediate_image_sizes = get_intermediate_image_sizes();

		// Create the full array with sizes and crop info
		foreach( $get_intermediate_image_sizes as $_size ) {
			if ( in_array( $_size, array( 'thumbnail', 'medium', 'medium_large', 'large' ) ) ) {
				$sizes[ $_size ]['width'] 	= get_option( $_size . '_size_w' );
				$sizes[ $_size ]['height'] 	= get_option( $_size . '_size_h' );
				$sizes[ $_size ]['crop'] 	= (bool) get_option( $_size . '_crop' );
			} elseif ( isset( $_wp_additional_image_sizes[ $_size ] ) ) {
				$sizes[ $_size ] = array(
					'width' 	=> $_wp_additional_image_sizes[ $_size ]['width'],
					'height' 	=> $_wp_additional_image_sizes[ $_size ]['height'],
					'crop' 		=> $_wp_additional_image_sizes[ $_size ]['crop'],
				);
			}
		}

		$image_sizes = array();

		foreach ( $sizes as $size_key => $size_attributes ) {
			$image_sizes[ $size_key ] = ucwords( str_replace( '_', ' ', $size_key ) ) . sprintf( ' - %d x %d', $size_attributes['width'], $size_attributes['height'] );
		}

		$image_sizes['full'] 	= _x( 'Full', 'Image Size Control', 'showbook' );

		return $image_sizes;
	}

	protected function render() {
		$settings = $this->get_settings();

		// Vars
		$posts_per_page = $settings['count'];
		$order 			= $settings['order'];
		$orderby  		= $settings['orderby'];
		$include 		= $settings['include_categories'];

		$args = array(
			'post_type'         => 'portfolio',
			'posts_per_page'    => $posts_per_page,
			'order'             => $order,
			'orderby'           => $orderby
		);

		// Include category
		if ( ! empty( $include ) ) {

			// Sanitize category and convert to array
			$include = str_replace( ', ', ',', $include );
			$include = explode( ',', $include );

			// Add to query arg
			$args['tax_query'][] = array(
				'taxonomy' => 'portfolio-type',
				'field'    => 'slug',
				'terms'    => $include,
				'operator' => 'IN',
			);

		}

		// Build the WordPress query
		$portfolio = new \WP_Query( $args );

		// Output posts
		if ( $portfolio->have_posts() ) :

			// Vars
			$filters   		= $settings['filters'];
			$title   		= $settings['title'];
			$cat 			= $settings['cat'];
			$gutter 		= $settings['gutter'];
			$gutter_size 	= $settings['gutter_size'];
			$style 		    = $settings['style'];

			// Image size
			$img_size 		= $settings['image_size'];
			$img_size 		= $img_size ? $img_size : 'medium';

			// Wrapper classes
			$wrap_classes = array( 'showbook-portfolio' );

			if ( !$gutter ) {
				$wrap_classes[] = 'no-gutter';
			}

			if ( 'small' == $gutter_size ) {
				$wrap_classes[] = 'small-gutter';
			}

			if ( 'modern' == $style ) {
				$wrap_classes[] = 'modern-style';
			}

			if ( 'two_col' == $style ) {
				$wrap_classes[] = 'two-columns-style';
			}

			if ( 'four_col' == $style ) {
				$wrap_classes[] = 'four-columns-style';
			}

			$wrap_classes = implode( ' ', $wrap_classes ); ?>

			<?php
			// Display filters if $filters is true.
			if ( 'true' == $filters ) { ?>

				<ul id="portfolio-filters">
					<li class="active"><a href="#" data-filter="*" class="selected"><?php esc_html_e( 'Show All', 'showbook' ) ?></a></li>
					<?php
						$terms = get_terms( 'portfolio-type' );
						$count = count( $terms );
						if ( $count > 0 ) {
							foreach ( $terms as $term ) {
								echo "<li><a href='#' data-filter='." . esc_attr( $term->taxonomy . '-' . $term->slug ) . "'>" . $term->name . "</a></li>\n";
							}
						}
					?>
				</ul>

			<?php } ?>

			<div class="<?php echo esc_attr( $wrap_classes ); ?>">

				<?php $counter = 1 ?>

				<?php

				// Start loop
				while ( $portfolio->have_posts() ) : $portfolio->the_post();

					// Post classes
					$post_classes = array( 'masonry-layout' );

					if ( 'modern' == $style ) {
						if ( $counter % 3 == 1 ) {
							$post_classes[] = 'big-post';
						}
					}

					// Create new post object.
					$post = new \stdClass();

					// Get post data
					$get_post = get_post();

					// Post Data
					$post->ID           = $get_post->ID;
					$post->permalink    = get_the_permalink( $post->ID );
					$post->title        = $get_post->post_title;
					?>

					<article id="post-<?php the_ID(); ?>" <?php post_class( $post_classes ); ?>>

						<div class="showbook-portfolio-inner">

							<?php
							// Display thumbnail if enabled and defined
							if ( has_post_thumbnail() ) { ?>

								<div class="showbook-portfolio-media">

									<a href="<?php echo esc_url( $post->permalink ); ?>" title="<?php the_title(); ?>" class="showbook-portfolio-img">

										<?php
										// Display post thumbnail
										the_post_thumbnail( $img_size, array(
											'alt'		=> get_the_title()
										) ); ?>

									</a>

								</div><!-- .showbook-portfolio-media -->

							<?php } ?>

							<div class="showbook-portfolio-details">

								<?php
								// Display title if $title is true and there is a post title
								if ( 'true' == $title ) { ?>

									<h2 class="showbook-portfolio-title entry-title">
										<a href="<?php echo esc_url( $post->permalink ); ?>" title="<?php the_title(); ?>"><?php echo esc_html( $post->title ); ?></a>
									</h2>

								<?php } ?>

								<?php
								// Display meta
								if ( 'true' == $cat ) { ?>

									<span class="showbook-portfolio-terms"><?php echo get_the_term_list( get_the_ID(), 'portfolio-type', '', ', ' ) ?></span>

								<?php } ?>

							</div><!-- .showbook-portfolio-details -->

						</div>

					</article>

				<?php
				// End entry loop
				$counter++; endwhile; ?>

			</div><!-- .showbook-portfolio -->

			<?php
			// Reset the post data to prevent conflicts with WP globals
			wp_reset_postdata();

		// If no posts are found display message
		else : ?>

			<p><?php _e( 'It seems we can&rsquo;t find what you&rsquo;re looking for.', 'showbook' ); ?></p>

		<?php
		// End post check
		endif; ?>

	<?php
	}

}

Plugin::instance()->widgets_manager->register_widget_type( new Showbook_Portfolio_Widget() );
